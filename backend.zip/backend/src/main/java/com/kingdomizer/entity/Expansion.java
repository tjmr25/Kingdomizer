package com.kingdomizer.entity;

public enum Expansion {
    BASE_2ND,
    PROSPERITY_2ND,
    SEASIDE_2ND
}
