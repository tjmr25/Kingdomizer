package com.kingdomizer.entity;

public enum CardType {
    ACTION,      
    REACTION,
    ATTACK,
    VICTORY,
    TREASURE,
    DURATION     
}
